class HelloStudent {
    public static void main(String[] args) {
        System.out.println("Hi, I am student at VIT Pune");
    }
}